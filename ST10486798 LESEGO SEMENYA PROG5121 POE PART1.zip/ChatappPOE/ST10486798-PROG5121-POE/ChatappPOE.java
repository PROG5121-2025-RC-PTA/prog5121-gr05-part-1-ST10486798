/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppoe;

import java.util.Scanner;
import java.io.*;
import java.net.*;   
    
//ST10486798
//LESEGO SEMENYA
//PART1 PROG5121 POE

/**
 *
 * @author RC_Student_lab
 */
public class ChatappPOE {
    
     private static boolean isCorrectInput(String input) {
          
        return input.contains("_") && input.length()<=5;
        }
     
     public static boolean returnLoginStatus(String status){
    if (status.equalsIgnoreCase( "Login successful")){
         return true;
    } else {
             return false;
        }
         
    }
     public static  void main (String[] args) {
   
            String status1 = "login successful";
            String status2 = "login failed";
        


        // Server address
        String serverAddress = "localhost"; 
        // Server port
        int port = 12345;  

        try (Socket socket = new Socket(serverAddress, port);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {

        //Scanner object to take user details
        Scanner myInput = new Scanner(System.in);
       
        
        //username and password for comparison
        String corUsername = null;
        String corPassword = null;
 
        //Prompt the user for username, password and cellphone number
            System.out.println("Enter your username: ");
            String username = myInput.nextLine();
        
        if (username.contains("_")&& username.length()==5 &&
            username.equals(corUsername)){
            
        System.out.println("Username captured successfully!");
       
        }
        else{
           System.out.println("Please re enter a username, must contain an ubderscore and must not be longer than 5 characters.");
           // return;
        }
   
           System.out.println("Enter your password: ");
                String password = myInput.nextLine();
        
    
        if (password.length()>=8 &&
            password.matches(".*[A-Z].*")&&
            password.matches(".*[0-9].*")&&
            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")&&
            password.equals(corPassword)){
        System.out.println("Password captured successfully!");
        }
        else{
            System.out.println("Password must be less than 8 characters");
            System.out.println("Password must contain a special character");
            System.out.println("Password must contain a capital letter");
            System.out.println("Password must contain a number");
            System.out.println("Please make sure your password includes. ");
            
            //return true;
        }

            System.out.println("Enter your cellphone number: ");
            String cellphoneNumber = myInput.nextLine();
            
         
        //regex, a pattern of characters thatdescribes a set of stringd
        String regex = "^\\+\\d{1,4}\\d{9}";
 
    
        if  (cellphoneNumber.length()==13 && 
            cellphoneNumber.startsWith("+27")&&
            cellphoneNumber.matches(regex))
            {
                System.out.println("cellphone numbers captured successful!");
              //  return true;
        }else{
            System.out.println("The cellphone number must contain +27 as a country code and must not be more than 10 characters");
        }
    
  
        //Validation for a cellphone south african format
            System.out.println("Account created successfully!");
            System.out.println("Username: "+ username);
        // System.out.println("Password: "+password);
            System.out.println("Cellphone Number: "+ cellphoneNumber);
            
        //boolean
            boolean checkUserNamer = isCorrectInput(username);
            boolean checkPasswordComplexity = isCorrectInput(password);
         
        //returning login status
        if (checkUserNamer && checkPasswordComplexity){
             
            if (username.equals(corUsername)&&
            password.equals(corPassword)){
                System.out.println("Login successful! Welcome, "+ username+ " ! "); 
        }else{
                System.out.println("Incorrect username or password. Please try again"); 
             }
        }    
            System.out.println(returnLoginStatus(status1));
            System.out.println(returnLoginStatus(status1));
        
        
            System.out.println("Connected to server.");
            while (true) {
                System.out.print("Enter a name (or type 'exit' to quit): ");
                username = userInput.readLine();
                if (username.equalsIgnoreCase("exit")) {
                    break;
                }
                //Send name to server
                System.out.println(username); 
                // Server's acknowledgment
                System.out.println(reader.readLine()); 
                // List of names stored
                System.out.println(reader.readLine());  
            }
        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
        
        String username=null;
        
         System.out.println("Welcome " + username+ "It's great to see you ");
    }  

}
    

    


